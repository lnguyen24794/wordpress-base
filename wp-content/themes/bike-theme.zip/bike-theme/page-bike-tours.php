<?php
/**
 * Template Name: Bike Tours Page
 *
 * @package Bike_Theme
 */

get_header();
?>

<main id="primary" class="site-main">

</main><!-- #main -->

<?php
get_footer();
?> 